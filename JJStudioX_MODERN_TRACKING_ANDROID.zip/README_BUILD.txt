JJ Studio X — Modern + Media Import + 3D Tracking Beta

Isi project:
- app/src/main/assets/index.html: UI modern, import foto/video/audio, ekstrak audio, curve editor, timeline, layer, keyframe dan 3D Tracking beta.
- MainActivity.java: Android WebView file chooser mengikuti MIME types input HTML, termasuk media dan file project JSON, serta mekanisme simpan file.

Build APK:
- Buka folder project melalui Android Studio / environment build Gradle.
- Untuk membuat APK debug, jalankan: gradle assembleDebug (memerlukan Android SDK dan Android Gradle Plugin yang cocok).
- Output normal: app/build/outputs/apk/debug/app-debug.apk

Catatan:
- Pemutaran video tergantung codec yang didukung WebView. MP4 H.264 + AAC biasanya pilihan paling kompatibel.
- 3D Tracking masih beta: memakai patch tracking pada frame video dengan estimasi skala sederhana. Ini bukan full 3D camera solve profesional.
- Ekstrak audio menggunakan kemampuan Web Audio/MediaRecorder browser; dukungan format bisa bervariasi di tiap perangkat.
