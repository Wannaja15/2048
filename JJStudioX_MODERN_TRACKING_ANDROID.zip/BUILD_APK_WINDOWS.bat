@echo off
echo JJ Studio X - Android build
if not exist gradlew.bat (
  echo Gradle wrapper is not included in this source package.
  echo Open this folder in Android Studio, let Gradle sync, then Build APK.
  pause
  exit /b 1
)
call gradlew.bat assembleDebug
pause
