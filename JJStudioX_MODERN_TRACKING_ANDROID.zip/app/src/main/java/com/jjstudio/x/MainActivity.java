package com.jjstudio.x;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.OutputStream;
import java.util.ArrayList;
import java.util.LinkedHashSet;

public class MainActivity extends Activity {
    private static final int REQUEST_PICK_MEDIA = 4101;
    private static final int REQUEST_SAVE_FILE = 4102;

    private WebView webView;
    private ValueCallback<Uri[]> fileChooserCallback;
    private byte[] pendingSaveBytes;
    private String pendingSaveName = "JJ-Studio-X-file";
    private String pendingSaveMime = "application/octet-stream";

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED
        );
        setContentView(R.layout.activity_main);

        webView = findViewById(R.id.webview);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setSupportZoom(false);

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(
                    WebView view,
                    ValueCallback<Uri[]> filePathCallback,
                    FileChooserParams fileChooserParams
            ) {
                if (fileChooserCallback != null) {
                    fileChooserCallback.onReceiveValue(null);
                }
                fileChooserCallback = filePathCallback;

                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                // Respect the MIME types requested by each HTML input (media picker or project JSON).
                LinkedHashSet<String> requested = new LinkedHashSet<>();
                String[] accepted = fileChooserParams.getAcceptTypes();
                if (accepted != null) {
                    for (String entry : accepted) {
                        if (entry == null) continue;
                        for (String part : entry.split("[,;]")) {
                            String mime = part.trim().toLowerCase(java.util.Locale.ROOT);
                            if (mime.contains("/") && !mime.startsWith(".")) requested.add(mime);
                        }
                    }
                }
                if (requested.isEmpty()) {
                    requested.add("image/*");
                    requested.add("video/*");
                    requested.add("audio/*");
                    requested.add("application/json");
                }
                if (requested.size() == 1) {
                    intent.setType(requested.iterator().next());
                } else {
                    intent.setType("*/*");
                    intent.putExtra(Intent.EXTRA_MIME_TYPES, requested.toArray(new String[0]));
                }
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, false);
                try {
                    startActivityForResult(intent, REQUEST_PICK_MEDIA);
                    return true;
                } catch (ActivityNotFoundException exception) {
                    fileChooserCallback = null;
                    Toast.makeText(MainActivity.this, "Tidak ada aplikasi pemilih file", Toast.LENGTH_SHORT).show();
                    return false;
                }
            }
        });
        webView.addJavascriptInterface(new FileSaveBridge(), "JJAndroid");
        webView.setOverScrollMode(WebView.OVER_SCROLL_NEVER);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private class FileSaveBridge {
        @JavascriptInterface
        public void saveFile(String fileName, String mimeType, String base64Data) {
            try {
                if (base64Data == null || base64Data.isEmpty()) {
                    runOnUiThread(() -> Toast.makeText(MainActivity.this, "File kosong", Toast.LENGTH_SHORT).show());
                    return;
                }
                byte[] decoded = Base64.decode(base64Data, Base64.DEFAULT);
                String safeName = fileName == null ? "JJ-Studio-X-file" : fileName.replaceAll("[\\\\/:*?\"<>|]", "_");
                String safeMime = mimeType == null || mimeType.trim().isEmpty()
                        ? "application/octet-stream" : mimeType;
                runOnUiThread(() -> beginSaveDocument(decoded, safeName, safeMime));
            } catch (Exception exception) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "Gagal menyiapkan file", Toast.LENGTH_LONG).show());
            }
        }
    }

    private void beginSaveDocument(byte[] bytes, String fileName, String mimeType) {
        pendingSaveBytes = bytes;
        pendingSaveName = fileName;
        pendingSaveMime = mimeType;
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType(mimeType);
        intent.putExtra(Intent.EXTRA_TITLE, fileName);
        try {
            startActivityForResult(intent, REQUEST_SAVE_FILE);
        } catch (ActivityNotFoundException exception) {
            pendingSaveBytes = null;
            Toast.makeText(this, "Tidak ada aplikasi untuk menyimpan file", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_PICK_MEDIA) {
            if (fileChooserCallback != null) {
                Uri[] result = null;
                if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                    result = new Uri[]{data.getData()};
                }
                fileChooserCallback.onReceiveValue(result);
                fileChooserCallback = null;
            }
            return;
        }

        if (requestCode == REQUEST_SAVE_FILE) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingSaveBytes != null) {
                try (OutputStream output = getContentResolver().openOutputStream(data.getData(), "w")) {
                    if (output == null) throw new IllegalStateException("Output file tidak tersedia");
                    output.write(pendingSaveBytes);
                    output.flush();
                    Toast.makeText(this, "File berhasil disimpan", Toast.LENGTH_LONG).show();
                } catch (Exception exception) {
                    Toast.makeText(this, "Gagal menyimpan file", Toast.LENGTH_LONG).show();
                }
            }
            pendingSaveBytes = null;
            pendingSaveName = "JJ-Studio-X-file";
            pendingSaveMime = "application/octet-stream";
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (fileChooserCallback != null) {
            fileChooserCallback.onReceiveValue(null);
            fileChooserCallback = null;
        }
        if (webView != null) {
            webView.removeJavascriptInterface("JJAndroid");
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
